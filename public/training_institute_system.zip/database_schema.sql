-- ====================================================================
-- Training Institute Student Management System
-- Upazila Computer Training Institute, Jhikargacha, Jashore
-- Database Schema & Pre-seeded Sample Records
-- ====================================================================

CREATE DATABASE IF NOT EXISTS `training_institute_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `training_institute_db`;

-- Table 1: Users
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(50) PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `full_name` VARCHAR(150) NOT NULL,
  `gender` VARCHAR(20) DEFAULT 'Male',
  `role` VARCHAR(50) DEFAULT 'Admin',
  `password_hash` VARCHAR(255) NOT NULL,
  `avatar_url` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table 2: Subjects
CREATE TABLE IF NOT EXISTS `subjects` (
  `id` VARCHAR(50) PRIMARY KEY,
  `code` VARCHAR(20) NOT NULL UNIQUE,
  `name` VARCHAR(150) NOT NULL
);

-- Table 3: Class Sessions
CREATE TABLE IF NOT EXISTS `class_sessions` (
  `id` VARCHAR(50) PRIMARY KEY,
  `starting_month` VARCHAR(20) NOT NULL,
  `ending_month` VARCHAR(20) NOT NULL,
  `year` VARCHAR(10) NOT NULL,
  `subject_id` VARCHAR(50),
  `duration` VARCHAR(50) NOT NULL,
  `monthly_tuition_fees` DECIMAL(10,2) DEFAULT 500,
  `is_active` BOOLEAN DEFAULT TRUE,
  `total_students` INT DEFAULT 0,
  `male_count` INT DEFAULT 0,
  `female_count` INT DEFAULT 0,
  FOREIGN KEY (`subject_id`) REFERENCES `subjects`(`id`) ON DELETE SET NULL
);

-- Table 4: Students
CREATE TABLE IF NOT EXISTS `students` (
  `id` VARCHAR(50) PRIMARY KEY,
  `roll` VARCHAR(50) NOT NULL UNIQUE,
  `name_en` VARCHAR(150) NOT NULL,
  `name_bn` VARCHAR(150),
  `father_name` VARCHAR(150) NOT NULL,
  `mother_name` VARCHAR(150) NOT NULL,
  `gender` VARCHAR(20) NOT NULL,
  `religion` VARCHAR(50),
  `blood_group` VARCHAR(10),
  `physical_disability` VARCHAR(10) DEFAULT 'No',
  `identity_type` VARCHAR(20) DEFAULT 'NID',
  `identity_number` VARCHAR(50),
  `student_mobile` VARCHAR(30) NOT NULL,
  `guardian_mobile` VARCHAR(30) NOT NULL,
  `whatsapp_no` VARCHAR(30),
  `address` TEXT,
  `academic_type` VARCHAR(50),
  `academic_year` VARCHAR(10),
  `academic_roll` VARCHAR(50),
  `academic_reg` VARCHAR(50),
  `academic_result` VARCHAR(20),
  `school_name` VARCHAR(150),
  `class_session_id` VARCHAR(50),
  `group_name` VARCHAR(10) DEFAULT 'A',
  `total_fee_paid` DECIMAL(10,2) DEFAULT 0,
  `attendance_percentage` INT DEFAULT 100,
  `result_grade` VARCHAR(10) DEFAULT 'Pending',
  `result_marks` INT DEFAULT 0,
  `admission_date` VARCHAR(30),
  `photo_url` TEXT,
  FOREIGN KEY (`class_session_id`) REFERENCES `class_sessions`(`id`) ON DELETE SET NULL
);

-- Table 5: Fee Transactions
CREATE TABLE IF NOT EXISTS `fee_transactions` (
  `id` VARCHAR(50) PRIMARY KEY,
  `receipt_number` VARCHAR(50) NOT NULL UNIQUE,
  `student_id` VARCHAR(50),
  `student_roll` VARCHAR(50),
  `student_name` VARCHAR(150),
  `month` VARCHAR(50),
  `date` VARCHAR(50),
  `total` DECIMAL(10,2) NOT NULL,
  `deposit` DECIMAL(10,2) NOT NULL,
  `previous_balance` DECIMAL(10,2) DEFAULT 0,
  `total_deposit` DECIMAL(10,2) NOT NULL,
  `balance_remaining` DECIMAL(10,2) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE
);

-- Table 6: Accounts
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` VARCHAR(50) PRIMARY KEY,
  `date` VARCHAR(30) NOT NULL,
  `type` ENUM('income', 'expense') NOT NULL,
  `description` VARCHAR(255) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `category` VARCHAR(100),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default Admin User (Password: admin123)
INSERT INTO `users` (`id`, `username`, `email`, `full_name`, `gender`, `role`, `password_hash`)
VALUES ('usr-admin-1', 'admin', 'admin@institute.gov.bd', 'Eleas Kanchon', 'Male', 'Admin', 'admin123')
ON DUPLICATE KEY UPDATE `username`=`username`;

-- Default Subjects
INSERT INTO `subjects` (`id`, `code`, `name`) VALUES
('sub-1', '76', 'Computer Office Applications'),
('sub-2', '79', 'Database Programming'),
('sub-3', '81', 'Graphic Design & Multimedia')
ON DUPLICATE KEY UPDATE `name`=`name`;

-- Default Sessions
INSERT INTO `class_sessions` (`id`, `starting_month`, `ending_month`, `year`, `subject_id`, `duration`, `monthly_tuition_fees`, `is_active`, `total_students`, `male_count`, `female_count`) VALUES
('ses-1', 'Jul', 'Dec', '2026', 'sub-1', '6 Month', 500, TRUE, 45, 23, 22),
('ses-2', 'Jul', 'Sep', '2026', 'sub-2', '3 Month', 600, FALSE, 38, 20, 18),
('ses-3', 'Jan', 'Jun', '2026', 'sub-1', '6 Month', 500, FALSE, 50, 26, 24)
ON DUPLICATE KEY UPDATE `is_active`=`is_active`;
